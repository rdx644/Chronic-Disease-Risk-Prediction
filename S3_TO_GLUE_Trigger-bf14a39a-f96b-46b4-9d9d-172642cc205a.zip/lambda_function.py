import json
import boto3
import os

# Get the region from the environment, where it is always set in Lambda
AWS_REGION = os.environ.get('AWS_REGION')

# Configure the Glue client, specifying the region explicitly for robustness
GLUE_CLIENT = boto3.client('glue', region_name=AWS_REGION)

# Hardcoded job name as provided by the user
GLUE_JOB_NAME = 'S3_to_Glue_to_S3'

def lambda_handler(event, context):
    """
    Handles S3 ObjectCreated events and triggers the AWS Glue job.
    
    Since the Glue job is configured to read the entire S3_RAW_INPUT_PATH 
    (which is hardcoded in the Glue script), this Lambda simply triggers the job 
    upon detection of a new file.
    """
    
    # We should now see this print statement if the client initialization above succeeded
    print(f"Received event: {json.dumps(event)}")
    
    # Optional: Log the S3 file path that triggered this event
    try:
        bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']
        print(f"New file created in S3: s3://{bucket}/{key}. Triggering Glue job.")
    except (IndexError, KeyError):
        print("Could not extract S3 information from event records.")
    
    try:
        # Start the Glue job run
        response = GLUE_CLIENT.start_job_run(
            JobName=GLUE_JOB_NAME,
            # Arguments are omitted because the paths are hardcoded in the Glue script
        )
        
        job_run_id = response.get('JobRunId')
        print(f"Successfully started Glue Job '{GLUE_JOB_NAME}' with ID: {job_run_id}")
        
        return {
            'statusCode': 200,
            'body': json.dumps(f"Glue job started: {job_run_id}")
        }
        
    except GLUE_CLIENT.exceptions.ResourceNotFoundException:
        error_message = f"Glue Job '{GLUE_JOB_NAME}' not found. Check job name and region."
        print(error_message)
        raise Exception(error_message)
        
    except Exception as e:
        error_message = f"Error starting Glue job: {str(e)}"
        print(error_message)
        raise Exception(error_message)
