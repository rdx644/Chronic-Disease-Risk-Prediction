import json
import boto3

# Initialize the DynamoDB client
dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    """
    This Lambda function processes data from API Gateway and saves it to DynamoDB.
    """
    try:
        # Log the received event for debugging purposes
        print("Received event: " + json.dumps(event, indent=2))

        # Check if the event body exists
        if 'body' not in event:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                    'Access-Control-Allow-Headers': 'Content-Type'
                },
                'body': json.dumps({'message': 'Missing request body'})
            }

        # Parse the JSON body from the API Gateway event
        body = json.loads(event['body'])
        
        # Ensure 'submissionId' and 'email' exist in the body
        if 'submissionId' not in body or 'email' not in body:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                    'Access-Control-Allow-Headers': 'Content-Type'
                },
                'body': json.dumps({'message': 'Missing submissionId or email in request body'})
            }

        # Get a reference to your DynamoDB table
        table = dynamodb.Table('WellifyHealthData')
        
        # Prepare the item to be put into the table
        # All form data from the body is saved, with submissionId as the key
        # The 'email' field is now also explicitly included
        item = {
            'submissionId': body['submissionId'],
            'email': body['email'],
            'age': body.get('age'),
            'gender': body.get('gender'),
            'height_cm': body.get('height_cm'),
            'weight_kg': body.get('weight_kg'),
            'bmi': body.get('bmi'),
            'region': body.get('region'),
            'smoking_status': body.get('smoking_status'),
            'alcohol_consumption': body.get('alcohol_consumption'),
            'sleep_hours_per_day': body.get('sleep_hours_per_day'),
            'diet_quality': body.get('diet_quality'),
            'physical_activity_level': body.get('physical_activity_level'),
            'stress_level': body.get('stress_level'),
            'blood_pressure_sys': body.get('blood_pressure_sys'),
            'blood_pressure_dia': body.get('blood_pressure_dia'),
            'cholesterol_level': body.get('cholesterol_level'),
            'glucose_level': body.get('glucose_level')
        }

        # Use put_item to save the data. It will create a new item or overwrite an existing one
        # with the same submissionId.
        response = table.put_item(Item=item)
        
        # Return a success response with the submissionId
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({
                'message': 'Data saved successfully!',
                'submissionId': item['submissionId']
            })
        }

    except Exception as e:
        # Log the error and return a 500 status code
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                'Access-Control-Allow-Headers': 'Content-Type'
            },
            'body': json.dumps({'message': 'Internal Server Error', 'error': str(e)})
        }
