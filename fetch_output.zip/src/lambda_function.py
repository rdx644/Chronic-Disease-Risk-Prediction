import json
import boto3
from botocore.exceptions import ClientError
from decimal import Decimal

# Initialize DynamoDB client
# Ensure the Lambda role has IAM permissions for dynamodb:Scan on the specified table.
dynamodb = boto3.resource('dynamodb')
TABLE_NAME = 'Final_predictions' 

# --- Custom JSON Encoder for DynamoDB Decimal/Set types ---
# DynamoDB can return Decimal objects which standard Python json.dumps cannot serialize.
# This custom handler converts Decimal to float/string for safe JSON output.
def default_serializer(obj):
    if isinstance(obj, Decimal):
        # Check if it is an integer (e.g., 5.0) or a float (e.g., 5.43)
        if obj % 1 == 0:
            return int(obj)
        return float(obj)
    # If the object type is not Decimal, fall back to the default serializer
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")

def lambda_handler(event, context):
    """
    Performs a full table scan on the DynamoDB table, handling pagination,
    and filters the results based on the 'email' provided in the request body.
    
    *** WARNING: Filtered Scans can still be expensive and slow on large tables. ***
    *** For production, prefer using DynamoDB Query on an index if possible. ***
    """
    try:
        table = dynamodb.Table(TABLE_NAME)
        
        # 1. Parse the request body to get the email
        try:
            body = json.loads(event['body'])
            search_email = body.get('email', '').lower()
        except (TypeError, KeyError, json.JSONDecodeError):
            # Handle cases where body is missing or malformed
            search_email = None

        if not search_email:
             return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': "Missing 'email' field in the request body."})
            }

        all_items = []
        response = None
        
        # Define the Scan parameters with the FilterExpression
        scan_params = {
            # FilterExpression reduces the returned data size
            'FilterExpression': 'email = :e',
            # ExpressionAttributeValues safely injects the variable
            'ExpressionAttributeValues': {
                ':e': search_email
            }
        }
        
        # Loop through results using the LastEvaluatedKey for pagination
        while response is None or 'LastEvaluatedKey' in response:
            if response is None:
                # First scan request
                response = table.scan(**scan_params)
            else:
                # Subsequent requests using the key from the previous batch
                scan_params['ExclusiveStartKey'] = response['LastEvaluatedKey']
                response = table.scan(**scan_params)
            
            # The filtering happens on the DynamoDB side (FilterExpression)
            all_items.extend(response.get('Items', []))

        print(f"Successfully fetched {len(all_items)} records for email: {search_email} from {TABLE_NAME}.")

        # Return the results to the client
        return {
            'statusCode': 200,
            'headers': {
                # CRITICAL: This allows your HTML page to fetch the data (CORS)
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            # Use the custom serializer for safe JSON encoding
            'body': json.dumps(all_items, default=default_serializer)
        }
        
    except ClientError as e:
        error_message = f"DynamoDB Client Error: {e.response['Error']['Message']}"
        print(error_message)
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': error_message})
        }
    except Exception as e:
        error_message = f"General Error: {str(e)}"
        print(error_message)
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': error_message})
        }
